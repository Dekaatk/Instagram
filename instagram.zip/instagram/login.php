<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <link rel="icon" href="pngegg2.png">
    <!-- Include SweetAlert2 CSS and JS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

    <style>
        body {
            background-image: url('giphy (4).gif');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            animation: backgroundAnimation 20s infinite alternate;
        }

        @keyframes backgroundAnimation {
            0% {
                background-position: 0 0;
            }
            100% {
                background-position: 100% 100%;
            }
        }

        .login-container {
            background-color: #ffffff; 
            padding: 90px;
            border-radius: 10px;
        }

        .login-form input[type="text"],
        .login-form input[type="password"],
        .login-form button {
            background-color: #000000;
            border: none;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
    </style>
    <title>AnimeRealm Login</title>
</head>
<body>
    <br><br><br><br><br><br>
    <div class="login-container">
        <div class="instagram-logo">
            <img src="logo.png" alt="Instagram Logo">
        </div>
        <form action="proses_login.php" class="login-form" method="post" id="loginForm">
            <input type="text" name="username" placeholder="Username or Email">
            <input type="password" name="password" placeholder="Password">
            <button type="submit">Log In</button>
        </form>

        <div class="forgot-password">
            <a href="#"></a>
        </div>
        <div class="separator">
            <span class="line"></span>
            <span class="or"></span>
            <span class="line"></span>
        </div>
        <div class="signup">
            <p></a></p>
        </div>
    </div>
    <!-- <script>
    document.getElementById('loginForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission
        
        // Get form data (you can use FormData for more complex forms)
        const username = document.getElementsByName('username')[0].value;
        const password = document.getElementsByName('password')[0].value;

        // Perform your login logic here, e.g., make an AJAX request to your server.
        // For demonstration, let's assume login failed.
        const loginFailed = true;

        if (loginFailed) {
            Swal.fire({
                title: 'Login Failed',
                text: 'Invalid username or password',
                icon: 'error',
                confirmButtonText: 'OK',
            });
        } else {
            Swal.fire({
        title: 'Login Successful',
        text: 'You have successfully logged in!',
        icon: 'success',
        confirmButtonText: 'OK',
            }).then((result) => {
        if (result.isConfirmed) {
            // Redirect to a success page or perform other actions on successful login
            window.location.href = 'index.php';
        }
    });
        }
    });
</script> -->

</body>
</html>

