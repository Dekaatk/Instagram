<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="pngegg.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" href="style.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
  <style>
        .card-img-top {
            transition: transform 0.3s; /* Add a transition effect for smooth zoom */
        }
        .card-img-top:hover {
            transform: scale(1.1); /* Increase the scale on hover (adjust the value as needed) */
        }
		/* Custom sidebar styles */
		.sidebar {
			position: fixed;
			top: 0;
			left: 0;
			width: 250px;
			height: 100%;
			background-color: #333;
			padding-top: 20px;
			color: #fff;
		}

		.sidebar-logo {
			text-align: center;
		}

		.sidebar-logo img {
			width: 80px;
			height: 80px;
		}

		.sidebar-logo h3 {
			margin-top: 10px;
		}

		.sidebar-menu {
			margin-top: 20px;
		}

		.sidebar-menu ul {
			list-style: none;
			padding: 0;
		}

		.sidebar-menu ul li {
			margin-bottom: 10px;
		}

		.sidebar-menu ul li a {
			text-decoration: none;
			color: #fff;
			font-size: 18px;
		}

		.sidebar-menu ul li a i {
			margin-right: 10px;
		}
    </style>
    <title>AnimeRealm</title>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-logo">
            <img src="download.png" alt="AnimeRealm">
            <h3>AnimeRealm</h3>
        </div>
        <div class="sidebar-menu">
            <ul>
                <li><a href="#"><i class="bi bi-house-door"></i> Home</a></li>
                <li><a href="#"><i class="bi bi-search"></i> Explore</a></li>
                <li><a href="#"><i class="bi bi-plus-square"></i> Create</a></li>
                <li><a href="#"><i class="bi bi-heart"></i> Notifications</a></li>
                <li><a href="#"><i class="bi bi-person"></i> Profile</a></li>
            </ul>
        </div>
        <div class="sidebar-logout">
            <a href="logout.php">
                <button class="btn btn-secondary">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </button>
            </a>
        </div>
    </div>

    <!-- Content -->
    <div class="container">
        <?php
        while ($post = mysqli_fetch_assoc($query)) {

        
        ?>
      
        <div class="card mt-3" style="width: 18rem;">
    <img src="images/<?= $post['gambar'] ?>" class="card-img-top" alt="...">
    <div class="card-body">
        <p class="card-text"><?= $post['caption'] ?></p>
        <p class="card-text"><?= $post['lokasi'] ?></p>
        <a href="hapus.php?no=<?= $post['no'] ?>" class="btn btn-danger"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
      <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
      </svg><span class="glyphicon glyphicon-trash"></span></a>
        <a href="edit.php?no=<?= $post['no'] ?>" class="btn btn-primary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
      <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
      <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
      </svg></a>  
    </div>
    </div>
    <?php  } ?>
    </div>
    </center>
    <!-- Include Bootstrap and other scripts here -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>
