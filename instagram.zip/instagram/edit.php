<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="text-center">
            <h1>Edit Post</h1>
        </div>
        <form action="proses_edit.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="no" value="<?= $post['no'] ?>">
            <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
            
            <div class="form-group">
                <label for="gambar">Gambar</label>
                <input type="file" class="form-control" name="gambar" id="gambar">
                <img src="images/<?= $post['gambar'] ?>" width="100" alt=""><br>
            </div>

            <div class="form-group">
                <label for="caption">Caption</label>
                <input type="text" class="form-control" name="caption" id="caption" value="<?= $post['caption'] ?>">
            </div>
            
            <div class="form-group">
                <label for="lokasi">Lokasi</label>
                <input type="text" class="form-control" name="lokasi" id="lokasi" value="<?= $post['lokasi'] ?>">
            </div>
            
            <div class="text-center">
                <input type="submit" class="btn btn-primary" value="Update" name="update">
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php } ?>
